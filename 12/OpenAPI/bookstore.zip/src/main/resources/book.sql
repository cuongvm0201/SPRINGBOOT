INSERT INTO book(title, author) VALUES('Ulysses', 'James Joyce');
INSERT INTO book(title, author) VALUES('The Great Gatsby', 'F. Scott Fitzgerald');
INSERT INTO book(title, author) VALUES('Brave New World', 'Aldous Huxley');
INSERT INTO book(title, author) VALUES('1984', 'George Orwell');
INSERT INTO book(title, author) VALUES('Tobacco Road', 'Erskine Caldwell');
INSERT INTO book(title, author) VALUES('Midnight’s Children', 'Salman Rushdie');
