# Exception Handling trong REST API



## Tham khảo
- [Error Handling for REST with Spring](https://www.baeldung.com/exception-handling-for-rest-with-spring)
- [Guide to Spring Boot REST API Error Handling](https://www.toptal.com/java/spring-boot-rest-api-error-handling)
- [Spring boot exception handling – @ExceptionHandler example](https://howtodoinjava.com/spring-boot2/spring-rest-request-validation/)