package vn.techmaster.bmiservice.response;

public record BMIResult(float index, String description) {
}
