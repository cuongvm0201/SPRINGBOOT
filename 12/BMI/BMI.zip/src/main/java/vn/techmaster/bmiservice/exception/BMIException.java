package vn.techmaster.bmiservice.exception;

public class BMIException extends RuntimeException{
  private static final long serialVersionUID = -4315753772384796683L;

  public BMIException(String message) {
    super(message);
  }
  
}
