package vn.techmaster.bmiservice.exception;

public class BMILogicException extends RuntimeException{
  private static final long serialVersionUID = 5857954733853635369L;

  public BMILogicException(String message) {
    super(message);
  }
  
}
