package vn.techmaster.bmiservice.request;

public record BMIRequest(float height, float weight){

}
