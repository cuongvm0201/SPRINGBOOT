package vn.techmasterr.jobhunt.model;

public record Employer(String name, String website, String email, String address) {
  
}
