package vn.techmasterr.jobhunt.model;

public record Job() {
  
}
