package vn.techmasterr.jobhunt.model;

public record Applicant(String fullname, String email, String mobile, String birthday) {
  
}
