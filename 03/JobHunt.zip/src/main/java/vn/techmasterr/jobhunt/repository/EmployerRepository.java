package vn.techmasterr.jobhunt.repository;

import org.springframework.stereotype.Repository;

@Repository
public class EmployerRepository {
  
}
