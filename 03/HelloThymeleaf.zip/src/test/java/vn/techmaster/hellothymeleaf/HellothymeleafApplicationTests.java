package vn.techmaster.hellothymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellothymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
