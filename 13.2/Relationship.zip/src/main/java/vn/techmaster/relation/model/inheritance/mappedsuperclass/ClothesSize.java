package vn.techmaster.relation.model.inheritance.mappedsuperclass;

public enum ClothesSize {  
  S, //small
  M, //medium
  L, //large
  XL, //extra large
  XXL //very extra large
}