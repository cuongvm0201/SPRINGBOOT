package vn.techmaster.relation.model.inheritance.mappedsuperclass;

public enum Color {
  RED,
  GREEN,
  BLUE,
  YELLOW,
  WHITE,
  BLACK,
  GREY,
  BROWN,
  NAVY,
  PINK
}
