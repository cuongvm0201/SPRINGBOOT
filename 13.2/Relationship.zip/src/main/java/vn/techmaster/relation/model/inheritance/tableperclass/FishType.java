package vn.techmaster.relation.model.inheritance.tableperclass;

public enum FishType {
  FRESH_WATER,
  SALT_WATER,
  BRACKISH_WATER
}
