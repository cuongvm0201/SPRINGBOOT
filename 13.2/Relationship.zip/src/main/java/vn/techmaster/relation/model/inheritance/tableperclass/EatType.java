package vn.techmaster.relation.model.inheritance.tableperclass;

public enum EatType {
  HERBIVO, //ăn lá cây
  CARNIVO, //ăn thịt
  OMNIVO //ăn tạp
}
