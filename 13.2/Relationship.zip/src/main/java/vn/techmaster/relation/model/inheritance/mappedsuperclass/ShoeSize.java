package vn.techmaster.relation.model.inheritance.mappedsuperclass;

public enum ShoeSize {  
  EU40,
  EU41,
  EU42,
  EU43,
  EU44,
  EU45,
  EU46
}
