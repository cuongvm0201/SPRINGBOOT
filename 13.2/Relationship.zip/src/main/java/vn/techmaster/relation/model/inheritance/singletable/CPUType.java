package vn.techmaster.relation.model.inheritance.singletable;

public enum CPUType {
  INTEL_CORE_I3,
  INTEL_CORE_I5,
  INTEL_CORE_I7, 
  INTEL_XEON,
  AMD_RYZEN,
  AMD_ATHLON
}
