package vn.techmaster.relation.model.inheritance.singletable;

public enum Voltage {
  DC9,
  DC12,
  DC48,
  AC110,
  AC220,
}
