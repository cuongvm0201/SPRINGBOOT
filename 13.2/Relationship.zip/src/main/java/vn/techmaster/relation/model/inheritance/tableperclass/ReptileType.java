package vn.techmaster.relation.model.inheritance.tableperclass;

public enum ReptileType {
  LIZARD,
  SNAKE,
  TURTLE,
  CROCODILE,
  GECKO
}
