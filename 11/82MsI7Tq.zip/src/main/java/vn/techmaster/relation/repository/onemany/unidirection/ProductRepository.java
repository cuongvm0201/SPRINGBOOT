package vn.techmaster.relation.repository.onemany.unidirection;

public interface ProductRepository {
  
}
