package vn.techmaster.simpleauthen.request;

public class SearchRequest {
  private String keyword;

  public String getKeyword() {
    return keyword;
  }

  public void setKeyword(String keyword) {
    this.keyword = keyword;
  }
}
