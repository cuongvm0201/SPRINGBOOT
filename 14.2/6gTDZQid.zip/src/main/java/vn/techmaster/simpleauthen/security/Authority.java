package vn.techmaster.simpleauthen.security;

public class Authority {
  public static final String READ = "READ";
  public static final String CREATE = "CREATE";
  public static final String DELETE = "DELETE";
  public static final String EDIT = "EDIT";
  public static final String SEARCH = "SEARCH";
  private Authority() {}
}
