package vn.techmaster.simpleauthen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleauthenApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleauthenApplication.class, args);
	}

}
