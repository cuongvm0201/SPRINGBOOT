package vn.techmaster.simpleauthen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleauthenApplicationTests {

	@Test
	void contextLoads() {
	}

}
